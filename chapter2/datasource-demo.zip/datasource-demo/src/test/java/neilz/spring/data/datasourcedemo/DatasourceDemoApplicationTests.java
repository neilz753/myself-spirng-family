package neilz.spring.data.datasourcedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatasourceDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
