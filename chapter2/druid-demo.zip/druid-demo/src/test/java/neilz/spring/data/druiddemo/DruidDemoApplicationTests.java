package neilz.spring.data.druiddemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DruidDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
